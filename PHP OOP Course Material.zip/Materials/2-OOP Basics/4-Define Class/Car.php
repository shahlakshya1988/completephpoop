<?php

    /*
     * Class Name First Letter should starts with Capital Letters.
     * File Name should match with Class Name. Easy to Follow.
     * One File should have One Class. You can have multiple.
     * 'class' is the keyword used to define a class.
     * class is opened and closed with {} like functions.
     *
     */


class Car
{
    function helloClass(){
        echo 'Hello from Car Class' . PHP_EOL;
    }
}

