<?php

    /*
     * Write PHP Program to Define Three Car Types and its Color.
     * Display Car Type and its Color.
     */

    //Car Type
    $sportsCar = "Ferrari";
    $modernCar = "BMW";
    $budgetCar = "Hundai";

    //Car Color
    $sportsCarColor = "Red";
    $modernCarColor = "Blue";
    $budgetCarColor = "Black";

    echo "Car: $sportsCar is $sportsCarColor Color" . PHP_EOL;
    echo "Car: $modernCar is $modernCarColor Color" . PHP_EOL;
    echo "Car: $budgetCar is $budgetCarColor Color" . PHP_EOL;



