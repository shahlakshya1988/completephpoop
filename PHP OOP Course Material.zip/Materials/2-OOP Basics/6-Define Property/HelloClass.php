<?php

/*
 * Define Class.
 * Define $content as Properties of Class
 * Define hello() method in the Class
 */

class HelloClass
{
    public $content;
    function hello(){
        echo "Hello Class from the hello() method";
    }
}
