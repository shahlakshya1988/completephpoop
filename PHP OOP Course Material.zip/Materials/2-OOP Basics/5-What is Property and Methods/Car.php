<?php


class Car
{
    public $name;
    public $color;
    public $size;
    public $model;
    public $type;

    function startCar() {}
    function increaseSpeed() {}
    function decreaseSpeed() {}
    function stopCar() {}
}



