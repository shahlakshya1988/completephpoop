<?php


interface Car
{

    public function applyBreak();
    public function increaseSpeed();
    public function decreaseSpeed();

}
