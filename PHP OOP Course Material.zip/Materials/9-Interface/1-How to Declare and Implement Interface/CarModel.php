<?php


interface CarModel
{
    public function setModel($model);
    public function getModel():string;
}