<?php


class Database
{
    function hello(){
        echo "Hello from Database Class" . PHP_EOL;
    }

}