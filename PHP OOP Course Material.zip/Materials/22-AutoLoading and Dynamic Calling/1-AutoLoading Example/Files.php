<?php


class Files
{
    function hello(){
        echo "Hello from Files Class" . PHP_EOL;
    }
}