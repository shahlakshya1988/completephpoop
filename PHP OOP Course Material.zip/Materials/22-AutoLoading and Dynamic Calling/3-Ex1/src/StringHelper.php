<?php namespace src;


class StringHelper
{
    function hello(){
        echo "Hello from StringHelper";
    }
}